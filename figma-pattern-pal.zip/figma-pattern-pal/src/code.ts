import type { StorageAdapter } from './types';
import { runPatternScan } from './cursorLogic';

figma.showUI(__html__, { width: 400, height: 400 });

const storage: StorageAdapter = {
  getAsync: (key: string) => figma.clientStorage.getAsync(key),
  setAsync: (key: string, value: unknown) =>
    figma.clientStorage.setAsync(key, value as string),
};

figma.ui.onmessage = async (msg: { type: string; width?: number; height?: number }) => {
  if (msg.type === 'SCAN_PATTERNS') {
    try {
      const result = await runPatternScan(storage);

      figma.ui.postMessage({
        type: 'SHOW_INSIGHTS',
        payload: {
          insights: result.insights,
          clusters: result.clusters,
          structuralDivergences: result.structuralDivergences,
        },
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      figma.ui.postMessage({
        type: 'SCAN_ERROR',
        payload: { error: message },
      });
    }
  } else if (msg.type === 'RESIZE') {
    figma.ui.resize(msg.width ?? 400, msg.height ?? 400);
  } else if (msg.type === 'CLOSE') {
    figma.closePlugin();
  }
};
