import type {
  FrameSnapshot,
  LayerNode,
  LayerContent,
  LayerDiff,
  StructuralDivergence,
} from './types';

function diffContent(
  a: LayerContent | undefined,
  b: LayerContent | undefined,
  path: string,
  idA: string,
  idB: string,
): LayerDiff[] {
  const diffs: LayerDiff[] = [];
  const ac = a ?? {};
  const bc = b ?? {};
  const keys = new Set<keyof LayerContent>([
    ...(Object.keys(ac) as (keyof LayerContent)[]),
    ...(Object.keys(bc) as (keyof LayerContent)[]),
  ]);

  const contentLabels: Record<string, string> = {
    fontName: 'Font',
    fills: 'Fill color',
    cornerRadius: 'Corner radius',
  };
  for (const k of keys) {
    const va = ac[k];
    const vb = bc[k];
    if (va === vb) continue;
    const label = contentLabels[k as keyof typeof contentLabels] ?? k;
    if (va === undefined && vb !== undefined) {
      diffs.push({
        path,
        kind: 'content-diff',
        detail: `${label}: only in second frame (${formatContentValue(k, vb)})`,
        instancePair: [idA, idB],
      });
    } else if (va !== undefined && vb === undefined) {
      diffs.push({
        path,
        kind: 'content-diff',
        detail: `${label}: only in first frame (${formatContentValue(k, va)})`,
        instancePair: [idA, idB],
      });
    } else if (va !== vb) {
      diffs.push({
        path,
        kind: 'content-diff',
        detail: `${label}: ${formatContentValue(k, va)} → ${formatContentValue(k, vb)}`,
        instancePair: [idA, idB],
      });
    }
  }
  return diffs;
}

function formatContentValue(key: keyof LayerContent, v: unknown): string {
  if (v === undefined || v === null) return '—';
  if (typeof v === 'number') return String(v);
  return String(v);
}

function getTextContent(node: LayerNode): string {
  if (node.type === 'TEXT' && node.characters) return node.characters.trim();
  for (const c of node.children) {
    const t = getTextContent(c);
    if (t) return t;
  }
  return '';
}

function diffLayers(
  a: LayerNode,
  b: LayerNode,
  path: string,
  idA: string,
  idB: string,
): LayerDiff[] {
  const diffs: LayerDiff[] = [];

  const containerTypes = ['FRAME', 'COMPONENT', 'INSTANCE'];
  const aIsContainer = containerTypes.includes(a.type);
  const bIsContainer = containerTypes.includes(b.type);
  if (a.type !== b.type) {
    const sameName = a.name === b.name;
    const bothContainers = aIsContainer && bIsContainer;
    if (bothContainers && sameName) {
      diffs.push({
        path,
        kind: 'type-mismatch',
        detail: `Different type: ${a.type} vs ${b.type} (same name «${a.name}»—consider using the same component)`,
        instancePair: [idA, idB],
      });
    } else {
      const compName = (a as LayerNode & { mainComponentName?: string }).mainComponentName ?? (b as LayerNode & { mainComponentName?: string }).mainComponentName;
      const detail = compName
        ? `Different type: ${a.type} vs ${b.type} (average uses component «${compName}»)`
        : `Different type: ${a.type} vs ${b.type}`;
      diffs.push({
        path,
        kind: 'type-mismatch',
        detail,
        instancePair: [idA, idB],
      });
      if (!bothContainers) return diffs;
    }
  }

  if (a.visible !== b.visible) {
    diffs.push({
      path,
      kind: 'visibility-diff',
      detail: a.visible ? 'Visible in first → hidden in second' : 'Hidden in first → visible in second',
      instancePair: [idA, idB],
    });
  }

  if (a.type === 'TEXT' && b.type === 'TEXT') {
    const aText = (a.characters ?? '').trim();
    const bText = (b.characters ?? '').trim();
    if (aText !== bText) {
      diffs.push({
        path,
        kind: 'text-diff',
        detail: `Text differs: «${aText || '(empty)'}» → «${bText || '(empty)'}»`,
        instancePair: [idA, idB],
      });
    }
  }

  const contentDiffs = diffContent(a.content, b.content, path, idA, idB);
  diffs.push(...contentDiffs);

  if (a.children.length !== b.children.length) {
    diffs.push({
      path,
      kind: 'child-count-diff',
      detail: `Different number of children: ${a.children.length} vs ${b.children.length}`,
      instancePair: [idA, idB],
    });
  }

  const minLen = Math.min(a.children.length, b.children.length);
  for (let i = 0; i < minLen; i++) {
    const ac = a.children[i];
    const bc = b.children[i];
    const slotPath = `${path} > [${i}] ${ac.name}`;

    if (ac.name !== bc.name) {
      const aLabel = getTextContent(ac);
      const bLabel = getTextContent(bc);
      diffs.push({
        path: `${path} › slot ${i + 1}`,
        kind: 'replacement',
        detail: `At position ${i + 1}: «${ac.name}»${aLabel ? ` ("${aLabel}")` : ''} → «${bc.name}»${bLabel ? ` ("${bLabel}")` : ''}`,
        instancePair: [idA, idB],
      });
    }

    diffs.push(...diffLayers(ac, bc, slotPath, idA, idB));
  }

  for (let i = minLen; i < a.children.length; i++) {
    diffs.push({
      path: `${path} > [${i}] ${a.children[i].name}`,
      kind: 'missing',
      detail: `«${a.children[i].name}» exists in first frame but not in second`,
      instancePair: [idA, idB],
    });
  }

  for (let i = minLen; i < b.children.length; i++) {
    diffs.push({
      path: `${path} > [${i}] ${b.children[i].name}`,
      kind: 'extra',
      detail: `«${b.children[i].name}» exists in second frame but not in first`,
      instancePair: [idA, idB],
    });
  }

  return diffs;
}

export function compareFrames(
  a: FrameSnapshot,
  b: FrameSnapshot,
): LayerDiff[] {
  return diffLayers(a.layers, b.layers, a.name, a.id, b.id);
}

/** Short path for context: "Login > [0] Title > [1] Button" → "Login > Button" */
function getShortPath(path: string): string {
  const parts = path.split(' > ').map((p) => p.replace(/^\[\d+\]\s*/, '').trim()).filter(Boolean);
  return parts.length <= 2 ? parts.join(' > ') : `${parts[0]} > ${parts[parts.length - 1]}`;
}

/** Add human-readable reason and suggestion to diffs (selected vs average) */
function enrichDiffWithGuidance(diff: LayerDiff): LayerDiff {
  const where = getShortPath(diff.path);
  const prefix = where ? `In ${where}: ` : '';
  const extractFromDetail = (pattern: RegExp): string | undefined => {
    const m = diff.detail.match(pattern);
    return m ? m[1] : undefined;
  };
  switch (diff.kind) {
    case 'extra': {
      const name = extractFromDetail(/«([^»]+)»/) ?? 'this element';
      return {
        ...diff,
        reason: `Most frames have «${name}», but yours doesn't.`,
        suggestion: `${prefix}Add «${name}» to match the average.`,
      };
    }
    case 'missing': {
      const name = extractFromDetail(/«([^»]+)»/) ?? 'this element';
      return {
        ...diff,
        reason: `Your frame has «${name}», but most others don't.`,
        suggestion: `${prefix}Remove «${name}» to match the average, or add it to other frames if needed.`,
      };
    }
    case 'text-diff': {
      const yourMatch = diff.detail.match(/«([^»]*)» →/);
      const avgMatch = diff.detail.match(/→ «([^»]*)»/);
      const yourText = yourMatch ? yourMatch[1] : undefined;
      const avgText = avgMatch ? avgMatch[1] : undefined;
      return {
        ...diff,
        reason: `Your text "${yourText || '(empty)'}" differs from the average.`,
        suggestion: avgText !== undefined
          ? `${prefix}Use "${avgText}" instead of "${yourText || '(empty)'}".`
          : `${prefix}Align the text with other frames.`,
      };
    }
    case 'content-diff': {
      const label = diff.detail.split(':')[0]?.trim() ?? 'property';
      const onlySecond = diff.detail.includes('only in second');
      const onlyFirst = diff.detail.includes('only in first');
      const parenMatch = diff.detail.match(/\(([^)]+)\)/);
      const arrowMatch = diff.detail.match(/:\s*([^→]+)\s*→\s*(.+)/);
      if (onlySecond && parenMatch) {
        const avgVal = parenMatch[1].trim();
        return {
          ...diff,
          reason: `Most frames have ${label} "${avgVal}", but yours doesn't.`,
          suggestion: `${prefix}Add ${label} "${avgVal}".`,
        };
      }
      if (onlyFirst && parenMatch) {
        const yourVal = parenMatch[1].trim();
        return {
          ...diff,
          reason: `Your frame has ${label} "${yourVal}", but most others don't.`,
          suggestion: `${prefix}Remove or change ${label} "${yourVal}" to match the average.`,
        };
      }
      if (arrowMatch) {
        const yourVal = arrowMatch[1].trim();
        const avgVal = arrowMatch[2].trim();
        return {
          ...diff,
          reason: `Your ${label} "${yourVal}" differs from the average.`,
          suggestion: `${prefix}Use "${avgVal}" instead of "${yourVal}".`,
        };
      }
      return { ...diff, suggestion: `${prefix}Use the same ${label.toLowerCase()} as in other frames.` };
    }
    case 'replacement': {
      const yourMatch = diff.detail.match(/«([^»]+)»(?:\s*\([^)]*\))?\s*→/);
      const avgMatch = diff.detail.match(/→ «([^»]+)»(?:\s*\(([^)]*)\))?/);
      const yourElem = yourMatch ? yourMatch[1] : undefined;
      const avgElem = avgMatch ? avgMatch[1] : undefined;
      const avgLabel = avgMatch && avgMatch[2] ? avgMatch[2] : undefined;
      const displayAvg = avgLabel ? `«${avgElem}» ("${avgLabel}")` : (avgElem ? `«${avgElem}»` : undefined);
      const displayYour = yourElem ? `«${yourElem}»` : undefined;
      return {
        ...diff,
        reason: `At this position you have ${displayYour ?? 'a different element'}, the average uses ${displayAvg ?? 'something else'}.`,
        suggestion: displayAvg
          ? `${prefix}Use ${displayAvg} instead of ${displayYour ?? 'what you have'}.`
          : `${prefix}Use the same element and order as in other frames.`,
      };
    }
    case 'child-count-diff': {
      const match = diff.detail.match(/(\d+)\s+vs\s+(\d+)/);
      const yourCount = match ? parseInt(match[1], 10) : 0;
      const avgCount = match ? parseInt(match[2], 10) : 0;
      const delta = avgCount - yourCount;
      return {
        ...diff,
        reason: `Your frame has ${yourCount} elements, the average has ${avgCount}.`,
        suggestion:
          delta > 0
            ? `${prefix}Add ${delta} more element(s) to match the average (${avgCount} total).`
            : `${prefix}Remove ${-delta} element(s) to match the average (${avgCount} total).`,
      };
    }
    case 'type-mismatch': {
      const match = diff.detail.match(/(\w+)\s+vs\s+(\w+)/);
      const yourType = match ? match[1] : undefined;
      const avgType = match ? match[2] : undefined;
      const compMatch = diff.detail.match(/component «([^»]+)»/);
      const compName = compMatch ? compMatch[1] : undefined;
      const isFrameVsInstance = (yourType === 'FRAME' && avgType === 'INSTANCE') || (yourType === 'INSTANCE' && avgType === 'FRAME');
      let suggestion: string;
      if (isFrameVsInstance && compName) {
        suggestion = yourType === 'FRAME'
          ? `${prefix}Convert your frame to the «${compName}» component to match other frames.`
          : `${prefix}Other frames use a frame here—convert your component instance to a frame, or standardize on «${compName}».`;
      } else if (isFrameVsInstance) {
        suggestion = yourType === 'FRAME'
          ? `${prefix}Convert your frame to the same component instance other frames use.`
          : `${prefix}Other frames use a frame here—use the same structure.`;
      } else {
        suggestion = avgType ? `${prefix}Use ${avgType} instead of ${yourType}.` : `${prefix}Use the same component type.`;
      }
      return {
        ...diff,
        reason: `This element is ${yourType}, but the average uses ${avgType}.`,
        suggestion,
      };
    }
    case 'visibility-diff':
      return {
        ...diff,
        reason: diff.detail.includes('hidden in second')
          ? `This element is visible in your frame but hidden in most others.`
          : `This element is hidden in your frame but visible in most others.`,
        suggestion: diff.detail.includes('hidden in second')
          ? `${prefix}Hide this element to match the average.`
          : `${prefix}Show this element to match the average.`,
      };
    default:
      return diff;
  }
}

/** Reconcile conflicting diffs: e.g. "Use Link instead of Button" + "Remove Link" → frame has both, consolidate to one clear action */
function reconcileConflictingDiffs(diffs: LayerDiff[]): LayerDiff[] {
  const replacements = diffs.filter((d) => d.kind === 'replacement' && d.detail.includes('→'));
  const missings = diffs.filter((d) => d.kind === 'missing');
  const replaceByAvg = new Map<string, { your: string; avg: string; diff: LayerDiff }>();
  const replaceByYour = new Map<string, { your: string; avg: string; diff: LayerDiff }>();
  for (const r of replacements) {
    const m = r.detail.match(/«([^»]+)»(?:\s*\([^)]*\))?\s*→\s*«([^»]+)»/);
    if (m) {
      const your = m[1];
      const avg = m[2];
      replaceByAvg.set(avg, { your, avg, diff: r });
      replaceByYour.set(your, { your, avg, diff: r });
    }
  }
  const toRemove = new Set<number>();
  for (let i = 0; i < missings.length; i++) {
    const m = missings[i].detail.match(/«([^»]+)»/);
    const name = m ? m[1] : '';
    const replByAvg = replaceByAvg.get(name);
    const replByYour = replaceByYour.get(name);
    if (replByAvg) {
      toRemove.add(diffs.indexOf(missings[i]));
      const idx = diffs.indexOf(replByAvg.diff);
      if (idx >= 0) {
        const p = getShortPath(replByAvg.diff.path) ? `In ${getShortPath(replByAvg.diff.path)}: ` : '';
        diffs[idx] = {
          ...replByAvg.diff,
          suggestion: `${p}Replace «${replByAvg.your}» with «${replByAvg.avg}» and remove the duplicate «${replByAvg.avg}».`,
          reason: `You have «${replByAvg.your}» and a duplicate «${replByAvg.avg}». The average has only one «${replByAvg.avg}»—keep it, remove the rest.`,
        };
      }
    } else if (replByYour) {
      toRemove.add(diffs.indexOf(missings[i]));
      const idx = diffs.indexOf(replByYour.diff);
      if (idx >= 0) {
        const p = getShortPath(replByYour.diff.path) ? `In ${getShortPath(replByYour.diff.path)}: ` : '';
        diffs[idx] = {
          ...replByYour.diff,
          suggestion: `${p}Replace «${replByYour.your}» with «${replByYour.avg}» and remove the duplicate «${replByYour.your}».`,
          reason: `You have «${replByYour.your}» in multiple places. The average uses «${replByYour.avg}» here—replace and remove the duplicate.`,
        };
      }
    }
  }
  return diffs.filter((_, i) => !toRemove.has(i));
}

/** Find the frame that minimizes total diff count to all others (medoid = average) */
function findReferenceFrame(snapshots: FrameSnapshot[]): FrameSnapshot {
  if (snapshots.length === 0) throw new Error('No snapshots');
  if (snapshots.length === 1) return snapshots[0];
  let bestIdx = 0;
  let bestTotal = Infinity;
  for (let i = 0; i < snapshots.length; i++) {
    let total = 0;
    for (let j = 0; j < snapshots.length; j++) {
      if (i !== j) total += compareFrames(snapshots[i], snapshots[j]).length;
    }
    if (total < bestTotal) {
      bestTotal = total;
      bestIdx = i;
    }
  }
  return snapshots[bestIdx];
}

/** Convert diff count to consistency score 0–100 */
export function computeConsistencyScore(diffCount: number): number {
  return Math.round(Math.max(0, 100 / (1 + diffCount)));
}

export function detectStructuralDivergencesWithSelection(
  selected: FrameSnapshot[],
  all: FrameSnapshot[],
): StructuralDivergence[] {
  if (selected.length === 0 || all.length < 2) return [];

  const reference = findReferenceFrame(all);
  const consistencyScores: Record<string, number> = {};
  const allDiffs: LayerDiff[] = [];

  for (const s of selected) {
    let diffs = compareFrames(s, reference).map(enrichDiffWithGuidance);
    diffs = reconcileConflictingDiffs(diffs);
    allDiffs.push(...diffs);
    consistencyScores[s.id] = computeConsistencyScore(diffs.length);
  }

  const uniqueNames = [...new Set(selected.map((s) => s.name))];
  return [
    {
      name: uniqueNames.length === 1 ? uniqueNames[0] : uniqueNames.join(', '),
      frameIds: selected.map((s) => s.id),
      diffs: allDiffs,
      referenceLayers: reference.layers,
      consistencyScores,
    },
  ];
}

export function detectStructuralDivergences(
  snapshots: FrameSnapshot[],
): StructuralDivergence[] {
  if (snapshots.length < 2) return [];

  const allDiffs: LayerDiff[] = [];
  const frameIds = snapshots.map((s) => s.id);

  for (let i = 0; i < snapshots.length; i++) {
    for (let j = i + 1; j < snapshots.length; j++) {
      allDiffs.push(...compareFrames(snapshots[i], snapshots[j]));
    }
  }

  if (allDiffs.length === 0) return [];

  const uniqueNames = [...new Set(snapshots.map((s) => s.name))];
  return [
    {
      name: uniqueNames.length === 1 ? uniqueNames[0] : uniqueNames.join(', '),
      frameIds,
      diffs: allDiffs,
      referenceLayers: snapshots[0].layers,
    },
  ];
}
