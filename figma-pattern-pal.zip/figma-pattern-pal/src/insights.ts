import type { Cluster, Memory, Insight, InsightResult, Pattern, NameDivergence, StructuralDivergence } from './types';

function detectLabelInconsistency(cluster: Cluster): string | null {
  const labels = cluster.patterns
    .map((p) => p.inputLabels ?? [])
    .filter((arr) => arr.length > 0);
  if (labels.length < 2) return null;

  const len = labels[0].length;
  if (!labels.every((arr) => arr.length === len)) return null;

  const diffs: string[] = [];
  for (let i = 0; i < len; i++) {
    const vals = [...new Set(labels.map((arr) => arr[i]?.toLowerCase().trim() ?? ''))];
    if (vals.length > 1 && vals.some(Boolean)) {
      diffs.push(`position ${i + 1}: ${labels.map((a) => a[i]).join(' vs ')}`);
    }
  }
  return diffs.length > 0
    ? `Label inconsistencies: ${diffs.join('; ')}`
    : null;
}

export function generateFileInsights(clusters: Cluster[]): Insight[] {
  const insights: Insight[] = [];

  for (const cluster of clusters) {
    const counts = new Map<string, number>();
    for (const p of cluster.patterns) {
      counts.set(p.behavior, (counts.get(p.behavior) ?? 0) + 1);
    }

    let majorityBehavior = '';
    let majorityCount = 0;
    for (const [behavior, count] of counts) {
      if (count > majorityCount) {
        majorityBehavior = behavior;
        majorityCount = count;
      }
    }

    const outlierCount = cluster.patterns.length - majorityCount;
    if (outlierCount > 0) {
      insights.push({
        source: 'this-file',
        message: `Most ${cluster.patterns[0].type}s use '${majorityBehavior}' — ${outlierCount} differ`,
      });
    }

    const labelInconsistency = detectLabelInconsistency(cluster);
    if (labelInconsistency) {
      insights.push({
        source: 'this-file',
        message: labelInconsistency,
      });
    }
  }

  if (insights.length === 0 && clusters.length > 0) {
    insights.push({ source: 'this-file', message: 'All patterns are consistent!' });
  }

  return insights;
}

export function generateCrossFileInsights(
  clusters: Cluster[],
  memory: Memory,
): Insight[] {
  const insights: Insight[] = [];

  for (const cluster of clusters) {
    const entry = memory[cluster.fingerprint];
    if (!entry) continue;

    let memoryMajority = '';
    let maxCount = 0;
    for (const [behavior, count] of Object.entries(entry.behaviorCounts)) {
      if (count > maxCount) {
        memoryMajority = behavior;
        maxCount = count;
      }
    }

    const currentBehaviors = [...new Set(cluster.patterns.map((p) => p.behavior))];
    for (const currentBehavior of currentBehaviors) {
      if (currentBehavior !== memoryMajority) {
        insights.push({
          source: 'across-files',
          message: `Across files, '${memoryMajority}' is most common for this pattern — this file uses '${currentBehavior}'`,
          fingerprint: cluster.fingerprint,
        });
      }
    }
  }

  return insights;
}

export function detectNameDivergences(patterns: Pattern[]): NameDivergence[] {
  const byName = new Map<string, Pattern[]>();
  for (const p of patterns) {
    const key = p.name.toLowerCase().trim();
    const list = byName.get(key) ?? [];
    list.push(p);
    byName.set(key, list);
  }

  const divergences: NameDivergence[] = [];

  for (const [, group] of byName) {
    if (group.length < 2) continue;

    const variants = group.map((p) => ({
      patternId: p.id,
      inputCount: p.inputs.length,
      inputNames: p.inputs.map((i) => i.name),
      actionCount: p.actions.length,
      behavior: p.behavior,
    }));

    const hasDiff = variants.some((v, i) =>
      i > 0 && (
        v.inputCount !== variants[0].inputCount ||
        v.actionCount !== variants[0].actionCount ||
        v.behavior !== variants[0].behavior ||
        v.inputNames.join(',') !== variants[0].inputNames.join(',')
      ),
    );

    if (hasDiff) {
      divergences.push({ name: group[0].name, variants });
    }
  }

  return divergences;
}

export function generateInsights(
  clusters: Cluster[],
  memory: Memory,
  patterns?: Pattern[],
  structuralDivergences?: StructuralDivergence[],
): InsightResult {
  return {
    fileInsights: generateFileInsights(clusters),
    crossFileInsights: generateCrossFileInsights(clusters, memory),
    nameDivergences: patterns ? detectNameDivergences(patterns) : [],
    structuralDivergences: structuralDivergences ?? [],
  };
}
