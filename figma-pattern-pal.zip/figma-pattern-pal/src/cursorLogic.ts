import type { StorageAdapter } from './types';
import type {
  Pattern,
  NormalizedPattern,
  Cluster,
  InsightResult,
  Memory,
  StructuralDivergence,
} from './types';
import { getPatternContainers, getAllFrameSnapshots, getSelectedFrameSnapshots } from './figmaTraversal';
import { scanPatterns } from './scanner';
import { normalizePatterns } from './normalizer';
import { clusterPatterns } from './clustering';
import { loadMemory, updateMemory, evictMemory, saveMemory } from './memory';
import { generateInsights } from './insights';
import { detectStructuralDivergencesWithSelection } from './structuralDiff';

export interface ScanResult {
  patterns: Pattern[];
  normalized: NormalizedPattern[];
  clusters: Cluster[];
  insights: InsightResult;
  memory: Memory;
  structuralDivergences: StructuralDivergence[];
}

export async function runPatternScan(storage: StorageAdapter): Promise<ScanResult> {
  const containers = getPatternContainers();
  const patterns = scanPatterns(containers);
  const normalized = normalizePatterns(patterns);
  const clusters = clusterPatterns(normalized);

  const memory = await loadMemory(storage);
  const fingerprints = normalized.map((p) => p.fingerprint);
  const behaviors = normalized.map((p) => p.behavior);
  const updated = updateMemory(memory, fingerprints, behaviors);
  const evicted = evictMemory(updated);
  await saveMemory(storage, evicted);

  const selected = getSelectedFrameSnapshots();
  if (selected.length === 0) {
    throw new Error('Select at least one frame to compare.');
  }
  const all = getAllFrameSnapshots();
  if (all.length < 2) {
    throw new Error('Need at least 2 frames on the page to compare.');
  }
  const structuralDivergences = detectStructuralDivergencesWithSelection(selected, all);

  const insights = generateInsights(clusters, evicted, patterns, structuralDivergences);

  return {
    patterns,
    normalized,
    clusters,
    insights,
    memory: evicted,
    structuralDivergences,
  };
}
