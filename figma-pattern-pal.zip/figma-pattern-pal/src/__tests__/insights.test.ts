import { describe, it, expect } from 'vitest';
import { generateFileInsights, generateCrossFileInsights, generateInsights, detectNameDivergences } from '../insights';
import type { Cluster, Memory, Pattern } from '../types';

const mkCluster = (overrides: Partial<Cluster> = {}): Cluster => ({
  label: 'form · login · 2-4 fields · modal',
  fingerprint: 'fp1',
  patterns: [
    { patternId: 'p1', fingerprint: 'fp1', type: 'form', fieldCountRange: '2-4', behavior: 'submit', intent: 'login', context: 'modal' },
  ],
  divergences: [],
  ...overrides,
});

describe('generateFileInsights', () => {
  it('reports consistent patterns when single cluster with no divergences', () => {
    const insights = generateFileInsights([mkCluster()]);
    expect(insights).toEqual([{ source: 'this-file', message: 'All patterns are consistent!' }]);
  });

  it('flags outlier behaviors', () => {
    const cluster = mkCluster({
      patterns: [
        { patternId: 'p1', fingerprint: 'fp1', type: 'form', fieldCountRange: '2-4', behavior: 'submit', intent: 'login', context: 'modal' },
        { patternId: 'p2', fingerprint: 'fp1', type: 'form', fieldCountRange: '2-4', behavior: 'submit', intent: 'login', context: 'modal' },
        { patternId: 'p3', fingerprint: 'fp1', type: 'form', fieldCountRange: '2-4', behavior: 'auto-save', intent: 'login', context: 'modal' },
      ],
      divergences: ['Mixed behaviors: submit, auto-save'],
    });
    const insights = generateFileInsights([cluster, mkCluster({ fingerprint: 'fp2' })]);
    expect(insights).toContainEqual({
      source: 'this-file',
      message: "Most forms use 'submit' — 1 differ",
    });
  });

  it('flags label inconsistencies when same-cluster patterns have different input labels', () => {
    const cluster = mkCluster({
      patterns: [
        { patternId: 'p1', fingerprint: 'fp1', type: 'form', fieldCountRange: '1-3', behavior: 'submit', intent: 'login', context: 'modal', inputLabels: ['Email', 'Password'] },
        { patternId: 'p2', fingerprint: 'fp1', type: 'form', fieldCountRange: '1-3', behavior: 'submit', intent: 'login', context: 'modal', inputLabels: ['E-mail', 'Password'] },
      ],
      divergences: [],
    });
    const insights = generateFileInsights([cluster]);
    expect(insights.some((i) => i.message.startsWith('Label inconsistencies:'))).toBe(true);
  });
});

describe('generateCrossFileInsights', () => {
  it('returns empty when no memory match', () => {
    const insights = generateCrossFileInsights([mkCluster()], {});
    expect(insights).toEqual([]);
  });

  it('flags behavior mismatch with memory', () => {
    const memory: Memory = {
      fp1: { totalObservations: 10, behaviorCounts: { 'auto-save': 8, submit: 2 }, lastSeen: 0 },
    };
    const insights = generateCrossFileInsights([mkCluster()], memory);
    expect(insights).toEqual([
      { source: 'across-files', message: "Across files, 'auto-save' is most common for this pattern — this file uses 'submit'", fingerprint: 'fp1' },
    ]);
  });
});

describe('generateInsights', () => {
  it('combines file and cross-file insights', () => {
    const memory: Memory = {
      fp1: { totalObservations: 5, behaviorCounts: { 'auto-save': 4, submit: 1 }, lastSeen: 0 },
    };
    const result = generateInsights([mkCluster()], memory);
    expect(result.fileInsights).toHaveLength(1);
    expect(result.fileInsights[0].source).toBe('this-file');
    expect(result.crossFileInsights).toHaveLength(1);
    expect(result.crossFileInsights[0].source).toBe('across-files');
    expect(result.nameDivergences).toEqual([]);
  });
});

describe('detectNameDivergences', () => {
  it('returns empty when no same-named patterns exist', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'Search Filter', type: 'filter', inputs: [{ id: 'i3', name: 'Keyword', role: 'input' }, { id: 'i4', name: 'Category', role: 'input' }], actions: [{ id: 'a2', name: 'Apply', role: 'action-primary' }], behavior: 'auto-apply', intent: 'filter', context: 'panel' },
    ];
    expect(detectNameDivergences(patterns)).toEqual([]);
  });

  it('returns empty when same-named patterns are identical', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'Login Form', type: 'form', inputs: [{ id: 'i3', name: 'Email', role: 'input' }, { id: 'i4', name: 'Password', role: 'input' }], actions: [{ id: 'a2', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
    ];
    expect(detectNameDivergences(patterns)).toEqual([]);
  });

  it('detects different input counts for same-named patterns', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'Login Form', type: 'form', inputs: [{ id: 'i3', name: 'Email', role: 'input' }, { id: 'i4', name: 'Password', role: 'input' }, { id: 'i5', name: 'Remember', role: 'input' }], actions: [{ id: 'a2', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
    ];
    const result = detectNameDivergences(patterns);
    expect(result).toHaveLength(1);
    expect(result[0].name).toBe('Login Form');
    expect(result[0].variants[0].inputCount).toBe(2);
    expect(result[0].variants[1].inputCount).toBe(3);
  });

  it('detects different input names for same-named patterns', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'Login Form', type: 'form', inputs: [{ id: 'i3', name: 'Username', role: 'input' }, { id: 'i4', name: 'Password', role: 'input' }], actions: [{ id: 'a2', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
    ];
    const result = detectNameDivergences(patterns);
    expect(result).toHaveLength(1);
    expect(result[0].variants[0].inputNames).toEqual(['Email', 'Password']);
    expect(result[0].variants[1].inputNames).toEqual(['Username', 'Password']);
  });

  it('detects different behaviors for same-named patterns', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'Login Form', type: 'form', inputs: [{ id: 'i3', name: 'Email', role: 'input' }, { id: 'i4', name: 'Password', role: 'input' }], actions: [{ id: 'a2', name: 'Submit', role: 'action-primary' }], behavior: 'auto-save', intent: 'login', context: 'page' },
    ];
    const result = detectNameDivergences(patterns);
    expect(result).toHaveLength(1);
    expect(result[0].variants[0].behavior).toBe('submit');
    expect(result[0].variants[1].behavior).toBe('auto-save');
  });

  it('is case-insensitive for name matching', () => {
    const patterns: Pattern[] = [
      { id: 'p1', name: 'Login Form', type: 'form', inputs: [{ id: 'i1', name: 'Email', role: 'input' }, { id: 'i2', name: 'Password', role: 'input' }], actions: [{ id: 'a1', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
      { id: 'p2', name: 'login form', type: 'form', inputs: [{ id: 'i3', name: 'Email', role: 'input' }, { id: 'i4', name: 'Password', role: 'input' }, { id: 'i5', name: 'OTP', role: 'input' }], actions: [{ id: 'a2', name: 'Submit', role: 'action-primary' }], behavior: 'submit', intent: 'login', context: 'page' },
    ];
    const result = detectNameDivergences(patterns);
    expect(result).toHaveLength(1);
  });
});
