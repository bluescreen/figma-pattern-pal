import { describe, it, expect, vi, beforeEach } from 'vitest';
import { runPatternScan } from '../cursorLogic';
import type { RawContainer } from '../scanner';
import type { FrameSnapshot, LayerNode } from '../types';

function mkLayer(name: string, type: string, children: LayerNode[] = []): LayerNode {
  return { id: `id-${name}`, name, type, visible: true, children };
}

function mkFrame(id: string, name: string, layers: LayerNode): FrameSnapshot {
  return { id, name, layers };
}

const mockFrameSnapshots: FrameSnapshot[] = [
  mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [])),
  mkFrame('f2', 'Login', mkLayer('Login', 'FRAME', [])),
];

const mockContainers: RawContainer[] = [
  {
    id: 'f1',
    name: 'Login',
    role: 'container-form',
    behavior: 'submit-validation',
    intent: 'create',
    context: 'page',
    children: [
      { id: 'i1', name: 'Email', role: 'input' },
      { id: 'i2', name: 'Password', role: 'input' },
      { id: 'a1', name: 'Submit', role: 'action-primary' },
    ],
  },
  {
    id: 'f2',
    name: 'Filter',
    role: 'container-filter',
    behavior: 'auto-apply',
    intent: 'filter',
    context: 'panel',
    children: [
      { id: 'i3', name: 'Keyword', role: 'input' },
      { id: 'i4', name: 'Category', role: 'input' },
      { id: 'a2', name: 'Apply', role: 'action-primary' },
    ],
  },
];

const mockGetSelected = vi.fn(() => [mockFrameSnapshots[0]]);
const mockGetAll = vi.fn(() => mockFrameSnapshots);

vi.mock('../figmaTraversal', () => ({
  getPatternContainers: vi.fn(() => mockContainers),
  getSelectedFrameSnapshots: () => mockGetSelected(),
  getAllFrameSnapshots: () => mockGetAll(),
}));

const mockStorage = {
  getAsync: vi.fn().mockResolvedValue(undefined),
  setAsync: vi.fn().mockResolvedValue(undefined),
};

describe('runPatternScan', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockStorage.getAsync.mockResolvedValue(undefined);
  });

  it('returns full ScanResult structure', async () => {
    const result = await runPatternScan(mockStorage);

    expect(result).toHaveProperty('patterns');
    expect(result).toHaveProperty('normalized');
    expect(result).toHaveProperty('clusters');
    expect(result).toHaveProperty('insights');
    expect(result).toHaveProperty('memory');
    expect(result).toHaveProperty('structuralDivergences');

    expect(result.patterns).toHaveLength(2);
    expect(result.normalized).toHaveLength(2);
    expect(result.clusters.length).toBeGreaterThanOrEqual(1);
    expect(result.insights.fileInsights).toBeDefined();
    expect(result.insights.crossFileInsights).toBeDefined();
  });

  it('persists memory via storage', async () => {
    await runPatternScan(mockStorage);

    expect(mockStorage.setAsync).toHaveBeenCalled();
  });

  it('throws when no frame is selected', async () => {
    mockGetSelected.mockReturnValueOnce([]);

    await expect(runPatternScan(mockStorage)).rejects.toThrow(
      'Select at least one frame to compare.',
    );
  });

  it('throws when fewer than 2 frames on page', async () => {
    mockGetAll.mockReturnValueOnce([mockFrameSnapshots[0]]);

    await expect(runPatternScan(mockStorage)).rejects.toThrow(
      'Need at least 2 frames on the page to compare.',
    );
  });
});
