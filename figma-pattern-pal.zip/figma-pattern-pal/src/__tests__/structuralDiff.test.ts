import { describe, it, expect } from 'vitest';
import {
  compareFrames,
  detectStructuralDivergences,
  detectStructuralDivergencesWithSelection,
  computeConsistencyScore,
} from '../structuralDiff';
import type { FrameSnapshot, LayerNode } from '../types';

function mkLayer(name: string, type: string, children: LayerNode[] = [], chars?: string): LayerNode {
  return { id: `id-${name}`, name, type, visible: true, children, characters: chars };
}

function mkFrame(id: string, name: string, layers: LayerNode): FrameSnapshot {
  return { id, name, layers };
}

// Login screen builders (matching screenshot: 3-frame comparison)
/** Frame 2: Full — Email, Password, Forgot password?, Login, Login with Google, Don't have account? */
function loginScreenFull(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', [mkLayer('Placeholder', 'TEXT', [], 'm@example.com')]),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', [mkLayer('Placeholder', 'TEXT', [], 'Enter your password')]),
      mkLayer('Forgot Password', 'TEXT', [], 'Forgot your password?'),
    ]),
    mkLayer('Login Button', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login')]),
    mkLayer('Login with Google', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login with Google')]),
    mkLayer('Sign Up Link', 'TEXT', [], "Don't have an account? Sign up"),
  ]);
}

/** Frame 1: Basic — Email, Password, Sign in only. Missing Forgot password, Login with Google, Don't have account */
function loginScreenBasic(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Sign In Button', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Sign in')]),
  ]);
}

/** Frame 3: Username variant — Username instead of Email, description no period */
function loginScreenUsernameVariant(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account'),
    mkLayer('Username Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Username'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
      mkLayer('Forgot Password', 'TEXT', [], 'Forgot your password?'),
    ]),
    mkLayer('Login Button', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login')]),
    mkLayer('Login with Google', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login with Google')]),
    mkLayer('Sign Up Link', 'TEXT', [], "Don't have an account? Sign up"),
  ]);
}

/** For placeholder tests: empty/missing placeholder layers */
function loginScreenMissingPlaceholder(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', [mkLayer('Placeholder', 'TEXT', [], '')]),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Login Button', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login')]),
  ]);
}

/** Minimal: Email only, Password missing (for missing-input algorithm test) */
function loginScreenMissingPassword(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Login Button', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Login')]),
  ]);
}

describe('compareFrames', () => {
  it('returns empty for identical frames', () => {
    const a = mkFrame('f1', 'Login', loginScreenFull());
    const b = mkFrame('f2', 'Login', loginScreenFull());
    expect(compareFrames(a, b)).toEqual([]);
  });

  it('detects missing input (Password missing)', () => {
    const a = mkFrame('f1', 'Login', loginScreenFull());
    const b = mkFrame('f2', 'Login', loginScreenMissingPassword());
    const diffs = compareFrames(a, b);

    expect(diffs.some((d) => d.kind === 'child-count-diff')).toBe(true);
    // B lacks Password Input, Login with Google, Sign Up Link, etc.
    expect(diffs.some((d) => d.kind === 'missing' && d.detail.includes('Password Input'))).toBe(true);
    expect(diffs.some((d) => d.kind === 'replacement' || d.kind === 'missing')).toBe(true);
  });

  it('detects missing placeholder text', () => {
    const a = mkFrame('f1', 'Login', loginScreenFull());
    const b = mkFrame('f2', 'Login', loginScreenMissingPlaceholder());
    const diffs = compareFrames(a, b);

    // Empty placeholder text
    expect(diffs.some((d) =>
      d.kind === 'text-diff' && d.path.includes('Email Input') && d.detail.includes('(empty)')
    )).toBe(true);

    // Missing placeholder layer
    expect(diffs.some((d) =>
      d.kind === 'missing' && d.path.includes('Password Input') && d.path.includes('Placeholder')
    )).toBe(true);
  });

  it('detects different text labels (Email vs Username, description punctuation)', () => {
    const a = mkFrame('f1', 'Login', loginScreenFull());
    const b = mkFrame('f2', 'Login', loginScreenUsernameVariant());
    const diffs = compareFrames(a, b);

    // Email vs Username at slot 3
    expect(diffs.some((d) =>
      d.kind === 'replacement' && d.detail.includes('Email') && d.detail.includes('Username')
    )).toBe(true);

    // Description: "account." vs "account"
    expect(diffs.some((d) =>
      d.kind === 'text-diff' && d.detail.includes('account')
    )).toBe(true);
  });

  it('detects extra layer', () => {
    const a = mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Email', 'INSTANCE'),
      mkLayer('Submit', 'INSTANCE'),
    ]));
    const b = mkFrame('f2', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Email', 'INSTANCE'),
      mkLayer('Remember Me', 'INSTANCE'),
      mkLayer('Submit', 'INSTANCE'),
    ]));
    const diffs = compareFrames(a, b);
    // Position-based: at slot 2, A has Submit vs B has Remember Me
    expect(diffs.some((d) => d.kind === 'replacement' && d.detail.includes('Remember Me'))).toBe(true);
    // B has extra Submit at position 3
    expect(diffs.some((d) => d.kind === 'extra' && d.detail.includes('Submit'))).toBe(true);
  });

  it('detects visibility differences', () => {
    const layersA = mkLayer('Login', 'FRAME', [
      { ...mkLayer('Error', 'TEXT'), visible: true },
    ]);
    const layersB = mkLayer('Login', 'FRAME', [
      { ...mkLayer('Error', 'TEXT'), visible: false },
    ]);
    const diffs = compareFrames(mkFrame('f1', 'Login', layersA), mkFrame('f2', 'Login', layersB));
    expect(diffs.some((d) => d.kind === 'visibility-diff')).toBe(true);
  });

  it('detects order difference (Email first vs Password first)', () => {
    const a = mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Email Input', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Email')]),
      mkLayer('Password Input', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Password')]),
      mkLayer('Submit', 'INSTANCE'),
    ]));
    const b = mkFrame('f2', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Password Input', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Password')]),
      mkLayer('Email Input', 'INSTANCE', [mkLayer('Label', 'TEXT', [], 'Email')]),
      mkLayer('Submit', 'INSTANCE'),
    ]));
    const diffs = compareFrames(a, b);
    expect(diffs.some((d) => d.kind === 'replacement' && d.detail.includes('Email Input') && d.detail.includes('Password Input'))).toBe(true);
    expect(diffs.some((d) => d.detail.includes('position'))).toBe(true);
  });

  it('detects content differences (fontName, fills)', () => {
    const a = mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Label', 'TEXT', [], 'Email'),
    ]));
    const b = mkFrame('f2', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Label', 'TEXT', [], 'Email'),
    ]));
    (a.layers.children[0] as LayerNode & { content?: object }).content = { fontName: 'Inter / Regular' };
    (b.layers.children[0] as LayerNode & { content?: object }).content = { fontName: 'Inter / Bold' };
    const diffs = compareFrames(a, b);
    expect(diffs.some((d) => d.kind === 'content-diff' && d.detail.includes('Font'))).toBe(true);
  });

  it('detects type mismatch', () => {
    const a = mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Field', 'INSTANCE'),
    ]));
    const b = mkFrame('f2', 'Login', mkLayer('Login', 'FRAME', [
      mkLayer('Field', 'TEXT'),
    ]));
    const diffs = compareFrames(a, b);
    expect(diffs.some((d) => d.kind === 'type-mismatch')).toBe(true);
  });
});

describe('detectStructuralDivergences', () => {
  it('returns empty for unique frame names when identical', () => {
    const snapshots = [
      mkFrame('f1', 'Login', mkLayer('Login', 'FRAME', [])),
      mkFrame('f2', 'Register', mkLayer('Register', 'FRAME', [])),
    ];
    expect(detectStructuralDivergences(snapshots)).toEqual([]);
  });

  it('compares frames with different names (loose fallback)', () => {
    const snapshots = [
      mkFrame('f1', 'Frame 1', mkLayer('F1', 'FRAME', [mkLayer('Label', 'TEXT', [], 'Hello')])),
      mkFrame('f2', 'Frame 2', mkLayer('F2', 'FRAME', [mkLayer('Label', 'TEXT', [], 'World')])),
      mkFrame('f3', 'Frame 3', mkLayer('F3', 'FRAME', [mkLayer('Label', 'TEXT', [], 'Hi')])),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
    expect(result[0].name).toBe('Frame 1, Frame 2, Frame 3');
    expect(result[0].frameIds).toEqual(['f1', 'f2', 'f3']);
    expect(result[0].diffs.some((d) => d.kind === 'text-diff')).toBe(true);
  });

  it('returns empty when same-named frames are identical', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenFull()),
    ];
    expect(detectStructuralDivergences(snapshots)).toEqual([]);
  });

  it('detects divergences: fewer inputs (basic vs full)', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenBasic()),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
    expect(result[0].name).toBe('Login');
    expect(result[0].diffs.some((d) => d.kind === 'missing' || d.kind === 'replacement')).toBe(true);
    expect(result[0].referenceLayers).toBeDefined();
    expect(result[0].referenceLayers.name).toBe('Login');
  });

  it('detects divergences: missing placeholder', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenMissingPlaceholder()),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
    expect(result[0].diffs.some((d) => d.kind === 'text-diff')).toBe(true);
    expect(result[0].diffs.some((d) => d.kind === 'missing' && d.path.includes('Placeholder'))).toBe(true);
  });

  it('detects divergences: different labels (Email vs Username)', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenUsernameVariant()),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
    expect(result[0].diffs.some((d) =>
      d.kind === 'replacement' && d.detail.includes('Username')
    )).toBe(true);
  });

  it('handles 3+ variants of same name', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenBasic()),
      mkFrame('f3', 'Login', loginScreenUsernameVariant()),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
    expect(result[0].frameIds).toEqual(['f1', 'f2', 'f3']);
    expect(result[0].diffs.length).toBeGreaterThanOrEqual(4);
  });

  it('with selection: compares selected to average (medoid) and returns consistency scores', () => {
    const all = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'Login', loginScreenBasic()),
      mkFrame('f3', 'Login', loginScreenUsernameVariant()),
    ];
    const selected = [all[0], all[1]];
    const result = detectStructuralDivergencesWithSelection(selected, all);
    expect(result).toHaveLength(1);
    expect(result[0].consistencyScores).toBeDefined();
    expect(result[0].consistencyScores!['f1']).toBeDefined();
    expect(result[0].consistencyScores!['f2']).toBeDefined();
    expect(typeof result[0].consistencyScores!['f1']).toBe('number');
    expect(result[0].consistencyScores!['f1']).toBeGreaterThanOrEqual(0);
    expect(result[0].consistencyScores!['f1']).toBeLessThanOrEqual(100);
  });

  it('computeConsistencyScore: 0 diffs = 100', () => {
    expect(computeConsistencyScore(0)).toBe(100);
  });

  it('computeConsistencyScore: more diffs = lower score', () => {
    expect(computeConsistencyScore(1)).toBe(50);
    expect(computeConsistencyScore(5)).toBeLessThan(computeConsistencyScore(1));
  });

  it('is case-insensitive for name matching', () => {
    const snapshots = [
      mkFrame('f1', 'Login', loginScreenFull()),
      mkFrame('f2', 'login', loginScreenBasic()),
    ];
    const result = detectStructuralDivergences(snapshots);
    expect(result).toHaveLength(1);
  });
});
