import { describe, it, expect } from 'vitest';
import { scanPatterns, type RawContainer } from '../scanner';
import { normalizePatterns } from '../normalizer';
import { clusterPatterns } from '../clustering';
import { updateMemory, evictMemory } from '../memory';
import { generateInsights } from '../insights';
import { detectStructuralDivergences } from '../structuralDiff';
import type { Memory, LayerNode, FrameSnapshot } from '../types';

/* ── Helpers ── */

function mkLayer(
  name: string,
  type: string,
  children: LayerNode[] = [],
  chars?: string,
): LayerNode {
  return { id: `id-${name}`, name, type, visible: true, children, characters: chars };
}

function mkFrame(id: string, name: string, layers: LayerNode): FrameSnapshot {
  return { id, name, layers };
}

/* ── Login screen variants (matching screenshot: 3-frame comparison) ── */

/** Frame 2 (middle): Full login — Email, Password, Forgot password?, Login, Login with Google, Don't have account? Sign up */
function loginFull(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', [
        mkLayer('Placeholder', 'TEXT', [], 'm@example.com'),
      ]),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', [
        mkLayer('Placeholder', 'TEXT', [], 'Enter your password'),
      ]),
      mkLayer('Forgot Password', 'TEXT', [], 'Forgot your password?'),
    ]),
    mkLayer('Login Button', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Login'),
    ]),
    mkLayer('Login with Google', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Login with Google'),
    ]),
    mkLayer('Sign Up Link', 'TEXT', [], "Don't have an account? Sign up"),
  ]);
}

/** Frame 1 (top): Basic login — Email, Password, Sign in only. Missing: Forgot password?, Login with Google, Don't have account? */
function loginBasic(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Sign In Button', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Sign in'),
    ]),
  ]);
}

/** Frame 3 (bottom): Username variant — Username instead of Email, description ends without period */
function loginUsernameVariant(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account'),
    mkLayer('Username Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Username'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
      mkLayer('Forgot Password', 'TEXT', [], 'Forgot your password?'),
    ]),
    mkLayer('Login Button', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Login'),
    ]),
    mkLayer('Login with Google', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Login with Google'),
    ]),
    mkLayer('Sign Up Link', 'TEXT', [], "Don't have an account? Sign up"),
  ]);
}

/** For placeholder tests: full structure with empty/missing placeholders */
function loginEmptyPlaceholders(): LayerNode {
  return mkLayer('Login', 'FRAME', [
    mkLayer('Title', 'TEXT', [], 'Login'),
    mkLayer('Description', 'TEXT', [], 'Enter your email below to login to your account.'),
    mkLayer('Email Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Email'),
      mkLayer('Input Field', 'FRAME', [
        mkLayer('Placeholder', 'TEXT', [], ''),
      ]),
    ]),
    mkLayer('Password Input', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Password'),
      mkLayer('Input Field', 'FRAME', []),
    ]),
    mkLayer('Login Button', 'INSTANCE', [
      mkLayer('Label', 'TEXT', [], 'Login'),
    ]),
  ]);
}

/* ── Pattern containers for behavioral pipeline ── */

const mockContainers: RawContainer[] = [
  {
    id: 'login-form',
    name: 'Login Form',
    role: 'container-form',
    behavior: 'submit-validation',
    intent: 'create',
    context: 'page',
    children: [
      { id: 'l-email', name: 'Email', role: 'input' },
      { id: 'l-password', name: 'Password', role: 'input' },
      { id: 'l-remember', name: 'Remember Me', role: 'input' },
      { id: 'l-submit', name: 'Login', role: 'action-primary' },
    ],
  },
  {
    id: 'registration-form',
    name: 'Registration Form',
    role: 'container-form',
    behavior: 'inline-validation',
    intent: 'create',
    context: 'page',
    children: [
      { id: 'r-name', name: 'Name', role: 'input' },
      { id: 'r-email', name: 'Email', role: 'input' },
      { id: 'r-password', name: 'Password', role: 'input' },
      { id: 'r-confirm', name: 'Confirm Password', role: 'input' },
      { id: 'r-terms', name: 'Terms', role: 'input' },
      { id: 'r-submit', name: 'Register', role: 'action-primary' },
      { id: 'r-cancel', name: 'Cancel', role: 'action-secondary' },
    ],
  },
  {
    id: 'search-filter',
    name: 'Search Filter',
    role: 'container-filter',
    behavior: 'auto-apply',
    intent: 'filter',
    context: 'panel',
    children: [
      { id: 's-keyword', name: 'Keyword', role: 'input' },
      { id: 's-category', name: 'Category', role: 'input' },
      { id: 's-apply', name: 'Apply', role: 'action-primary' },
    ],
  },
  {
    id: 'advanced-filter',
    name: 'Advanced Filter',
    role: 'container-filter',
    behavior: 'confirm',
    intent: 'filter',
    context: 'panel',
    children: [
      { id: 'af-keyword', name: 'Keyword', role: 'input' },
      { id: 'af-category', name: 'Category', role: 'input' },
      { id: 'af-date-from', name: 'Date From', role: 'input' },
      { id: 'af-date-to', name: 'Date To', role: 'input' },
      { id: 'af-apply', name: 'Apply', role: 'action-primary' },
      { id: 'af-reset', name: 'Reset', role: 'action-secondary' },
    ],
  },
  {
    id: 'edit-profile',
    name: 'Edit Profile Form',
    role: 'container-form',
    behavior: 'submit-validation',
    intent: 'update',
    context: 'modal',
    children: [
      { id: 'ep-name', name: 'Name', role: 'input' },
      { id: 'ep-bio', name: 'Bio', role: 'input' },
      { id: 'ep-avatar', name: 'Avatar', role: 'input' },
      { id: 'ep-save', name: 'Save', role: 'action-primary' },
    ],
  },
  {
    id: 'contact-form',
    name: 'Contact Form',
    role: 'container-form',
    behavior: 'submit-validation',
    intent: 'create',
    context: 'modal',
    children: [
      { id: 'c-email', name: 'Email', role: 'input' },
      { id: 'c-message', name: 'Message', role: 'input' },
      { id: 'c-send', name: 'Send', role: 'action-primary' },
    ],
  },
];

/* ── Tests ── */

describe('e2e: full pipeline (behavioral + structural)', () => {
  it('runs behavioral pipeline: scan → normalize → cluster → insights', () => {
    const patterns = scanPatterns(mockContainers);
    expect(patterns).toHaveLength(6);

    const normalized = normalizePatterns(patterns);
    expect(normalized).toHaveLength(6);

    const clusters = clusterPatterns(normalized);
    expect(clusters.length).toBeGreaterThanOrEqual(2);

    const memory: Memory = {};
    for (const cluster of clusters) {
      memory[cluster.fingerprint] = {
        totalObservations: 10,
        behaviorCounts: { 'different-behavior': 8, 'other-behavior': 2 },
        lastSeen: Date.now() - 86400000,
      };
    }

    const insights = generateInsights(clusters, memory, patterns);
    const totalInsights =
      insights.fileInsights.length + insights.crossFileInsights.length;
    expect(totalInsights).toBeGreaterThanOrEqual(3);

    for (const ins of [...insights.fileInsights, ...insights.crossFileInsights]) {
      expect(ins.message).toBeTruthy();
    }
  });

  it('runs structural pipeline: detects login screens with missing elements (basic vs full)', () => {
    const snapshots: FrameSnapshot[] = [
      mkFrame('f1', 'Login', loginFull()),
      mkFrame('f2', 'Login', loginBasic()),
    ];

    const divergences = detectStructuralDivergences(snapshots);

    expect(divergences).toHaveLength(1);
    expect(divergences[0].name).toBe('Login');
    expect(divergences[0].frameIds).toEqual(['f1', 'f2']);

    // Basic lacks: Forgot password, Login with Google, Don't have account; has Sign in vs Login
    expect(divergences[0].diffs.some((d) => d.kind === 'child-count-diff')).toBe(true);
    expect(divergences[0].diffs.some((d) =>
      (d.kind === 'replacement' || d.kind === 'missing') &&
      (d.detail.includes('Sign in') || d.detail.includes('Login') || d.detail.includes('Forgot')),
    )).toBe(true);
  });

  it('runs structural pipeline: detects login screens with empty/missing placeholders', () => {
    const snapshots: FrameSnapshot[] = [
      mkFrame('f1', 'Login', loginFull()),
      mkFrame('f2', 'Login', loginEmptyPlaceholders()),
    ];

    const divergences = detectStructuralDivergences(snapshots);

    expect(divergences).toHaveLength(1);

    // Email placeholder is empty
    expect(divergences[0].diffs.some((d) =>
      d.kind === 'text-diff' &&
      d.path.includes('Email Input') &&
      d.detail.includes('(empty)'),
    )).toBe(true);

    // Password placeholder layer is missing
    expect(divergences[0].diffs.some((d) =>
      d.kind === 'missing' &&
      d.path.includes('Password Input') &&
      d.path.includes('Placeholder'),
    )).toBe(true);
  });

  it('runs structural pipeline: detects login screens with different labels (Email vs Username)', () => {
    const snapshots: FrameSnapshot[] = [
      mkFrame('f1', 'Login', loginFull()),
      mkFrame('f2', 'Login', loginUsernameVariant()),
    ];

    const divergences = detectStructuralDivergences(snapshots);

    expect(divergences).toHaveLength(1);

    // Email Input vs Username Input at slot 3
    expect(divergences[0].diffs.some((d) =>
      d.kind === 'replacement' && d.detail.includes('Email') && d.detail.includes('Username'),
    )).toBe(true);
    // Description: "account." vs "account" (punctuation)
    expect(divergences[0].diffs.some((d) =>
      d.kind === 'text-diff' && d.detail.includes('account'),
    )).toBe(true);
  });

  it('combines behavioral + structural: full pipeline simulation', () => {
    // 1. Behavioral pipeline
    const patterns = scanPatterns(mockContainers);
    const normalized = normalizePatterns(patterns);
    const clusters = clusterPatterns(normalized);

    let memory: Memory = {};
    const fingerprints = normalized.map((n) => n.fingerprint);
    const behaviors = normalized.map((n) => n.behavior);
    memory = updateMemory(memory, fingerprints, behaviors);
    const evicted = evictMemory(memory);

    // 2. Structural pipeline (3 login variants: full, basic, username)
    const snapshots: FrameSnapshot[] = [
      mkFrame('f1', 'Login', loginFull()),
      mkFrame('f2', 'Login', loginBasic()),
      mkFrame('f3', 'Login', loginUsernameVariant()),
    ];
    const structuralDivergences = detectStructuralDivergences(snapshots);

    // 3. Combined insights
    const insights = generateInsights(clusters, evicted, patterns, structuralDivergences);

    // Behavioral insights exist
    expect(insights.fileInsights.length).toBeGreaterThanOrEqual(1);

    // Structural divergences passed through
    expect(insights.structuralDivergences).toHaveLength(1);
    expect(insights.structuralDivergences[0].name).toBe('Login');
    expect(insights.structuralDivergences[0].diffs.length).toBeGreaterThanOrEqual(5);

    // Structural differences (basic lacks elements; username variant differs)
    expect(insights.structuralDivergences[0].diffs.some((d) =>
      d.kind === 'replacement' || d.kind === 'missing' || d.kind === 'text-diff',
    )).toBe(true);

    // Email vs Username replacement
    expect(insights.structuralDivergences[0].diffs.some((d) =>
      d.detail.includes('Email') || d.detail.includes('Username'),
    )).toBe(true);
  });

  it('handles memory update and eviction', () => {
    let memory: Memory = {};

    const patterns = scanPatterns(mockContainers);
    const normalized = normalizePatterns(patterns);
    const fingerprints = normalized.map((n) => n.fingerprint);
    const behaviors = normalized.map((n) => n.behavior);

    memory = updateMemory(memory, fingerprints, behaviors);
    expect(Object.keys(memory).length).toBeGreaterThan(0);

    for (const entry of Object.values(memory)) {
      expect(entry.totalObservations).toBeGreaterThanOrEqual(1);
    }

    const evicted = evictMemory(memory, 2);
    expect(Object.keys(evicted).length).toBeLessThanOrEqual(2);
  });

  it('detects behavioral divergences in similar patterns', () => {
    const filterContainers: RawContainer[] = [
      {
        id: 'filter-a',
        name: 'Filter A',
        role: 'container-filter',
        behavior: 'auto-apply',
        intent: 'filter',
        context: 'panel',
        children: [
          { id: 'fa-1', name: 'Keyword', role: 'input' },
          { id: 'fa-2', name: 'Category', role: 'input' },
          { id: 'fa-3', name: 'Apply', role: 'action-primary' },
        ],
      },
      {
        id: 'filter-b',
        name: 'Filter B',
        role: 'container-filter',
        behavior: 'confirm',
        intent: 'filter',
        context: 'panel',
        children: [
          { id: 'fb-1', name: 'Keyword', role: 'input' },
          { id: 'fb-2', name: 'Category', role: 'input' },
          { id: 'fb-3', name: 'Status', role: 'input' },
          { id: 'fb-4', name: 'Apply', role: 'action-primary' },
          { id: 'fb-5', name: 'Reset', role: 'action-secondary' },
        ],
      },
    ];

    const patterns = scanPatterns(filterContainers);
    expect(patterns).toHaveLength(2);

    const normalized = normalizePatterns(patterns);
    expect(normalized[0].fingerprint).toBe(normalized[1].fingerprint);

    const clusters = clusterPatterns(normalized);
    expect(clusters).toHaveLength(1);
    expect(clusters[0].divergences.length).toBeGreaterThan(0);
    expect(clusters[0].divergences[0]).toContain('auto-apply');
    expect(clusters[0].divergences[0]).toContain('confirm');
  });

  it('returns no structural divergences when all same-named frames are identical', () => {
    const snapshots: FrameSnapshot[] = [
      mkFrame('f1', 'Login', loginFull()),
      mkFrame('f2', 'Login', loginFull()),
      mkFrame('f3', 'Login', loginFull()),
    ];
    expect(detectStructuralDivergences(snapshots)).toEqual([]);
  });
});
