export interface ComponentRef {
  id: string;
  name: string;
  role: string;
  type?: string;
}

export interface Pattern {
  id: string;
  name: string;
  type: 'form' | 'filter';
  inputs: ComponentRef[];
  actions: ComponentRef[];
  behavior: string;
  intent: string;
  context: string;
}

export interface NormalizedPattern {
  patternId: string;
  fingerprint: string;
  type: 'form' | 'filter';
  fieldCountRange: string;
  behavior: string;
  intent: string;
  context: string;
  inputLabels?: string[];
}

export interface Cluster {
  label: string;
  fingerprint: string;
  patterns: NormalizedPattern[];
  divergences: string[];
}

export interface MemoryEntry {
  totalObservations: number;
  behaviorCounts: Record<string, number>;
  lastSeen: number;
}

export type Memory = Record<string, MemoryEntry>;

export interface NameDivergence {
  name: string;
  variants: NameDivergenceVariant[];
}

export interface NameDivergenceVariant {
  patternId: string;
  inputCount: number;
  inputNames: string[];
  actionCount: number;
  behavior: string;
}

/* ── Structural layer diff ── */

export interface LayerContent {
  text?: string;
  fontName?: string;
  fills?: string;
  cornerRadius?: number;
}

export interface LayerNode {
  id: string;
  name: string;
  type: string;
  visible: boolean;
  children: LayerNode[];
  characters?: string;
  content?: LayerContent;
  /** Component name when type is INSTANCE (mainComponent.name) */
  mainComponentName?: string;
}

export interface FrameSnapshot {
  id: string;
  name: string;
  layers: LayerNode;
  mainComponentId?: string;
}

export interface LayerDiff {
  path: string;
  kind:
    | 'missing'
    | 'extra'
    | 'type-mismatch'
    | 'text-diff'
    | 'content-diff'
    | 'visibility-diff'
    | 'child-count-diff'
    | 'replacement';
  detail: string;
  instancePair?: [string, string];
  /** Human-readable explanation why this differs from the average */
  reason?: string;
  /** Suggestion how to improve consistency */
  suggestion?: string;
}

export interface StructuralDivergence {
  name: string;
  frameIds: string[];
  diffs: LayerDiff[];
  referenceLayers: LayerNode;
  /** Consistency score 0–100 per frame (when using selection-based comparison) */
  consistencyScores?: Record<string, number>;
}

export type InsightSource = 'this-file' | 'across-files';

export interface Insight {
  source: InsightSource;
  message: string;
  fingerprint?: string;
}

export interface InsightResult {
  fileInsights: Insight[];
  crossFileInsights: Insight[];
  nameDivergences: NameDivergence[];
  structuralDivergences: StructuralDivergence[];
}

export type FormagotchiMood = 'calm' | 'confused' | 'annoyed' | 'overstimulated';

export interface FormagotchiState {
  mood: FormagotchiMood;
  line: string;
}

export interface StorageAdapter {
  getAsync(key: string): Promise<unknown>;
  setAsync(key: string, value: unknown): Promise<void>;
}
