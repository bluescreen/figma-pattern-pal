# Plan: Anpassung an PRD und TDD (isolierte Tasks)

Jede Task ist eigenständig, hat klare Akzeptanzkriterien und minimale Abhängigkeiten.

---

## Task 1: cursorLogic.ts erstellen

- **Datei:** `src/cursorLogic.ts` (neu)
- **Ref:** TDD §3.2, §3.3
- **Aktion:** Neue Datei mit `runPatternScan(storage: StorageAdapter)` erstellen
- **Pipeline:** getPatternContainers → scanPatterns → normalizePatterns → clusterPatterns → loadMemory → updateMemory → evictMemory → saveMemory → generateInsights → getFormagotchiState
- **Rückgabe:** `{ patterns, normalized, clusters, insights, formagotchi, memory }`
- **Abhängigkeiten:** Keine (nutzt bestehende Module)

---

## Task 2: cursorLogic.test.ts erstellen

- **Datei:** `src/__tests__/cursorLogic.test.ts` (neu)
- **Aktion:** Unit-Tests für `runPatternScan` mit gemockten Containern/storage
- **Abhängigkeiten:** Task 1

---

## Task 3: code.ts – Pipeline durch cursorLogic ersetzen

- **Datei:** `src/code.ts`
- **Aktion:** SCAN_PATTERNS-Handler: gesamte Pipeline-Logik entfernen, stattdessen `runPatternScan(storage)` aufrufen und Ergebnis an `figma.ui.postMessage` übergeben
- **Abhängigkeiten:** Task 1

---

## Task 4: code.ts – UI-Dimensionen 300x400

- **Datei:** `src/code.ts`
- **Aktion:** `figma.showUI(__html__, { width: 300, height: 400 })` setzen
- **Abhängigkeiten:** Keine

---

## Task 5: ui.html – Dimensionen anpassen

- **Datei:** `src/ui.html`
- **Aktion:** body/CSS width/height von 360x520 auf 300x400 anpassen
- **Abhängigkeiten:** Keine

---

## Task 6: SHOW_INSIGHTS Payload validieren

- **Dateien:** `src/code.ts`, `src/ui.html`
- **Aktion:** Prüfen ob Payload `{ insights, formagotchi, clusters }` mit aktueller UI kompatibel ist; bei Bedarf anpassen
- **Abhängigkeiten:** Task 3

---

## Task 7: code.ts – lastScanResult speichern

- **Datei:** `src/code.ts`
- **Aktion:** Nach erfolgreichem Scan: `lastScanResult = result` in Modulvariable speichern
- **Abhängigkeiten:** Task 3

---

## Task 8: ANNOTATE_CANVAS Handler implementieren

- **Datei:** `src/code.ts`
- **Aktion:** ANNOTATE_CANVAS-Handler: bei vorhandenem `lastScanResult` → `annotateCanvas(clusters, insights)` aufrufen; sonst Fehlermeldung an UI
- **Abhängigkeiten:** Task 7

---

## Task 9: Formagotchi memorySize nutzen

- **Datei:** `src/formagotchi.ts`
- **Aktion:** Parameter `memorySize` in `getFormagotchiState` nicht mehr ignorieren; in Mood- oder Line-Logik einbeziehen
- **Abhängigkeiten:** Keine

---

## Task 10: Tagline auf PRD setzen

- **Datei:** `src/ui.html`
- **Aktion:** Tagline-Text auf „A playful teammate that observes your design patterns and suggests alignment—without judging.“ ändern
- **Abhängigkeiten:** Keine

---

## Task 11: Label-Inkonsistenzen in Insights (P2)

- **Dateien:** `src/insights.ts`, `src/types.ts`
- **Aktion:** Insights um Erkennung von Label-Inkonsistenzen erweitern
- **Abhängigkeiten:** Keine

---

## Task 12: Annotations crossFileFingerprints robust machen (P2)

- **Dateien:** `src/insights.ts`, `src/types.ts`, `src/annotations.ts`
- **Aktion:** Insight um optionales `fingerprint` erweitern; Annotations nutzen fingerprint statt Message-Matching
- **Abhängigkeiten:** Keine

---

## Übersicht

| Task | Datei(en) | Abhängigkeit |
|------|-----------|---------------|
| 1 | cursorLogic.ts | – |
| 2 | cursorLogic.test.ts | 1 |
| 3 | code.ts | 1 |
| 4 | code.ts | – |
| 5 | ui.html | – |
| 6 | code.ts, ui.html | 3 |
| 7 | code.ts | 3 |
| 8 | code.ts | 7 |
| 9 | formagotchi.ts | – |
| 10 | ui.html | – |
| 11 | insights.ts, types.ts | – |
| 12 | insights.ts, types.ts, annotations.ts | – |

---

## Empfohlene Reihenfolge

1. Task 1, 4, 5, 9, 10 (parallel möglich)
2. Task 2 (nach 1)
3. Task 3 (nach 1)
4. Task 6 (nach 3)
5. Task 7 (nach 3)
6. Task 8 (nach 7)
7. Task 11, 12 (P2, optional)
